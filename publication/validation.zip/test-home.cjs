const {chromium}=require('playwright'),fs=require('fs'),assert=require('assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true}),page=await browser.newPage({viewport:{width:1440,height:900}});
 await page.route('**/*',r=>r.abort());
 await page.setContent('<base href="http://ludemis.test"><body class="theme-graphite"><div id="result"></div></body>');
 for(const file of ['style.css','studio.css','themes.css','branding.css'])await page.addStyleTag({content:fs.readFileSync(file,'utf8')});
 const source=fs.readFileSync('app.js','utf8');
 const start=source.indexOf('function homeFeaturedGame('),end=source.indexOf('\nfunction ',source.indexOf('function home(){')+1);
 await page.addScriptTag({content:`const data={games:[],catalog:[{cache_key:'popular',title:'Cyberpunk 2077',steam_app_id:'1091500',steam_positive:1000}]};const catalogKey=g=>g.cache_key||'';const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const short=s=>s;const official13Logo=()=>'';const catalogMedia=(key,kind='')=>'/missing/'+key+'/'+kind;const catalogRemoteImage=()=>'';const libraryCompletionStatus=()=>'';const empty=()=>'';const btn=label=>'<button class="btn primary large">'+label+'</button>';${source.slice(start,end)}document.querySelector('#result').innerHTML=home();`});
 await page.getByText('Cyberpunk 2077',{exact:true}).waitFor({state:'visible'});
 assert.equal(await page.getByText('EN TENDANCE · DANS TON CATALOGUE',{exact:true}).count(),0);
 assert.equal(await page.getByRole('button',{name:/Voir la fiche/}).count(),1);
 assert.equal(await page.getByText('Découvre ton prochain jeu',{exact:true}).count(),0);
 await page.locator('.home-feature').screenshot({path:'home-without-cache.png',animations:'disabled'});
 await browser.close();console.log('Home hero renders catalogue game and actions even when every image fails.');
})().catch(e=>{console.error(e);process.exit(1)});
