$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$folder = Join-Path $env:RUNNER_TEMP "Ludemis test O'Brien"
New-Item -ItemType Directory -Path $folder -Force | Out-Null
$target = Join-Path $folder 'Ludemis.exe'
$staged = Join-Path $folder 'staged.exe'
Copy-Item '..\Ludemis.exe' $staged
[byte[]]$old = [System.Text.Encoding]::UTF8.GetBytes('old executable fixture')
[System.IO.File]::WriteAllBytes($target, $old)
$hash = (Get-FileHash -LiteralPath $staged -Algorithm SHA256).Hash
function QuotePS($v) { "'" + $v.Replace("'", "''") + "'" }
# Use a real parent process so the installer must wait for its exit.
$parent = Start-Process powershell.exe -ArgumentList '-NoProfile','-Command','Start-Sleep -Seconds 3' -PassThru -WindowStyle Hidden
$template = [System.IO.File]::ReadAllText((Join-Path $PWD 'installer-template.ps1'))
foreach ($value in @((QuotePS $target),(QuotePS $staged),(QuotePS $hash))) {
  $at=$template.IndexOf('%s');$template=$template.Substring(0,$at)+$value+$template.Substring($at+2)
}
$template=$template.Replace('%d', [string]$parent.Id)
$script=Join-Path $folder 'install.ps1'
[System.IO.File]::WriteAllText($script,$template,(New-Object System.Text.UTF8Encoding($true)))
$env:APPDATA=Join-Path $folder 'Roaming'
$env:LOCALAPPDATA=Join-Path $folder 'Local'
New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA -Force | Out-Null
$sentinel=Join-Path $env:APPDATA 'existing-library-and-google-session.txt'
[System.IO.File]::WriteAllText($sentinel,'existing user data fixture')
$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS='--remote-debugging-port=9222'
$installer = Start-Process powershell.exe -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$script+'"') -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PWD 'installer-out.txt') -RedirectStandardError (Join-Path $PWD 'installer-err.txt')
$installerHandle=$installer.Handle
if (-not $installer.WaitForExit(60000)) { Stop-Process -Id $installer.Id -Force; throw 'Installer timed out' }
Get-Content (Join-Path $PWD 'installer-out.txt'),(Join-Path $PWD 'installer-err.txt')
if ($installer.ExitCode -ne 0) { throw ('Installer failed with exit code: '+$installer.ExitCode) }
if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $hash) { throw 'Replacement hash differs' }
if ([System.Text.Encoding]::UTF8.GetString([System.IO.File]::ReadAllBytes($target+'.previous')) -ne 'old executable fixture') { throw 'Backup lost' }
if ((Test-Path -LiteralPath $script) -or (Test-Path -LiteralPath $staged)) { throw 'Temporary files retained' }
Start-Sleep -Seconds 12
$running=Get-Process Ludemis -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $target }
if (-not $running) { throw 'Ludemis did not remain running after replacement' }
$bounds=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bitmap=New-Object System.Drawing.Bitmap($bounds.Width,$bounds.Height)
$graphics=[System.Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($bounds.Location,[System.Drawing.Point]::Empty,$bounds.Size)
$bitmap.Save((Join-Path $PWD 'windows-launch.png'))
$graphics.Dispose();$bitmap.Dispose()
[System.IO.File]::WriteAllText((Join-Path $PWD 'ludemis-pid.txt'),[string]$running.Id)
if ([System.IO.File]::ReadAllText($sentinel) -ne 'existing user data fixture') { throw 'User data changed' }
Write-Output 'Windows replacement, backup, parent wait, cleanup, data preservation and real Ludemis launch passed.'

# Failure handling: invalid executable with a matching hash must restore the old file.
$target=Join-Path $folder 'rollback.exe'
$staged=Join-Path $folder 'rollback-staged.exe'
[System.IO.File]::WriteAllBytes($target,$old)
[System.IO.File]::WriteAllBytes($staged,[System.Text.Encoding]::UTF8.GetBytes('MZ invalid executable fixture'))
$badHash=(Get-FileHash -LiteralPath $staged -Algorithm SHA256).Hash
$template=[System.IO.File]::ReadAllText((Join-Path $PWD 'installer-template.ps1'))
foreach ($value in @((QuotePS $target),(QuotePS $staged),(QuotePS $badHash))) {
 $at=$template.IndexOf('%s');$template=$template.Substring(0,$at)+$value+$template.Substring($at+2)
}
$template=$template.Replace('%d','2147483647')
[System.IO.File]::WriteAllText($script,$template,(New-Object System.Text.UTF8Encoding($true)))
$installer=Start-Process powershell.exe -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$script+'"') -PassThru -WindowStyle Hidden
$installerHandle=$installer.Handle
$closed=$false
for ($attempt=0;$attempt -lt 30;$attempt++) {
 Start-Sleep -Seconds 1
 $installer.Refresh()
 if ($installer.MainWindowHandle -ne 0) { $closed=$installer.CloseMainWindow();break }
 if ($installer.HasExited) { break }
}
if (-not $installer.WaitForExit(10000)) { Stop-Process -Id $installer.Id -Force;throw 'Error dialog could not be closed' }
if ([System.Text.Encoding]::UTF8.GetString([System.IO.File]::ReadAllBytes($target)) -ne 'old executable fixture') { throw 'Rollback failed' }
if (-not (Test-Path -LiteralPath ($target+'.previous'))) { throw 'Rollback consumed backup' }
Write-Output 'Windows rollback after launch failure passed.'
