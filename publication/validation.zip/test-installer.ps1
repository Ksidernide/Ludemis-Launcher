$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public class InstallerWindows {
 delegate bool Callback(IntPtr hwnd, IntPtr param);
 [DllImport("user32.dll")] static extern bool EnumWindows(Callback callback, IntPtr param);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr hwnd,StringBuilder text,int length);
 [DllImport("user32.dll")] static extern bool PostMessage(IntPtr hwnd,uint message,IntPtr w,IntPtr l);
 public static void Close(int process) {var hwnd=Find(process);if(hwnd!=IntPtr.Zero)PostMessage(hwnd,0x0010,IntPtr.Zero,IntPtr.Zero);}
 public static string Describe(int process) {var all=new StringBuilder();EnumWindows(delegate(IntPtr hwnd,IntPtr param){uint pid;GetWindowThreadProcessId(hwnd,out pid);if(pid==(uint)process){var title=new StringBuilder(256);GetWindowText(hwnd,title,256);all.Append(" pid="+pid+" hwnd="+hwnd+" visible="+IsWindowVisible(hwnd)+" title="+title);}return true;},IntPtr.Zero);return all.ToString();}
 public static IntPtr Find(int process) {
  IntPtr found=IntPtr.Zero;
  EnumWindows(delegate(IntPtr hwnd,IntPtr param){uint pid;GetWindowThreadProcessId(hwnd,out pid);if(pid==(uint)process && IsWindowVisible(hwnd)){var title=new StringBuilder(256);GetWindowText(hwnd,title,256);if(title.ToString()=="Ludemis"){found=hwnd;return false;}}return true;},IntPtr.Zero);
  return found;
 }
}
'@
$folder=Join-Path $env:RUNNER_TEMP "Ludemis test O'Brien"
New-Item -ItemType Directory -Path $folder -Force | Out-Null
$env:APPDATA=Join-Path $folder 'Roaming'
$env:LOCALAPPDATA=Join-Path $folder 'Local'
New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA -Force | Out-Null
$root=Join-Path $env:LOCALAPPDATA 'GamingHub\Updates'
New-Item -ItemType Directory -Path $root -Force | Out-Null
$target=Join-Path $folder 'Ludemis.exe'
$fixtureSource=Join-Path $folder 'fixture.cs'
[IO.File]::WriteAllText($fixtureSource,'class Program { static void Main() {} }')
& "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:winexe "/out:$target" $fixtureSource
if ($LASTEXITCODE -ne 0) { throw 'Fixture compilation failed' }
$originalHash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
$sentinel=Join-Path $env:APPDATA 'existing-library-and-google-session.txt'
[IO.File]::WriteAllText($sentinel,'existing user data fixture')
$config=Get-Content '..\publication\release.json' -Raw | ConvertFrom-Json
function QuotePS($v) { "'"+$v.Replace("'","''")+"'" }
function Prepare-Job($name,$targetPath,$broken) {
 $job=Join-Path $root $name
 New-Item -ItemType Directory -Path $job -Force | Out-Null
 $staged=Join-Path $job 'download.exe'
 if($broken){[IO.File]::WriteAllBytes($staged,[Text.Encoding]::UTF8.GetBytes('MZ invalid executable fixture'))}else{Copy-Item '..\Ludemis.exe' $staged}
 $hash=(Get-FileHash -LiteralPath $staged -Algorithm SHA256).Hash.ToLowerInvariant()
 $token=[Guid]::NewGuid().ToString('N')
 @{token=$token;version=$config.version;target=$targetPath;sha256=$hash} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $job 'job.json') -Encoding ASCII
 $parent=Start-Process powershell.exe -ArgumentList '-NoProfile','-Command','Start-Sleep -Seconds 3' -PassThru -WindowStyle Hidden
 $template=[IO.File]::ReadAllText((Join-Path $PWD 'installer-template.ps1'))
 foreach($value in @((QuotePS $targetPath),(QuotePS $staged),(QuotePS $hash),(QuotePS $job),(QuotePS $token))){$at=$template.IndexOf('%s');$template=$template.Substring(0,$at)+$value+$template.Substring($at+2)}
 $template=$template.Replace('%d',[string]$parent.Id)
 $template=$template.Replace('$script:form.Show()', '$script:form.Show(); Write-Output ("Form: pid=$PID visible="+$script:form.Visible+" handle="+$script:form.Handle+" title="+$script:form.Text)')
 $script=Join-Path $job 'install.ps1'
 [IO.File]::WriteAllText($script,$template,(New-Object Text.UTF8Encoding($true)))
 $pidFile=Join-Path $job 'powershell.pid'
 $launcher=Join-Path $PWD 'installer-launcher.exe'
 $argsList=@($script,(Join-Path $PWD ($name+'-out.txt')),(Join-Path $PWD ($name+'-err.txt')),$pidFile) | ForEach-Object {'"'+$_+'"'}
 $process=Start-Process -FilePath $launcher -ArgumentList $argsList -WindowStyle Hidden -PassThru
 $pidWait=[Diagnostics.Stopwatch]::StartNew()
 while(-not (Test-Path -LiteralPath $pidFile)){
  if($process.HasExited -or $pidWait.Elapsed.TotalSeconds -gt 15){throw 'The actual Go installer launcher did not start PowerShell'}
  Start-Sleep -Milliseconds 50
 }
 $childPID=[int]([IO.File]::ReadAllText($pidFile))
 $handle=$process.Handle
 return @{job=$job;hash=$hash;process=$process;parent=$parent;childPID=$childPID}
}
$test=Prepare-Job 'job-success' $target $false
# Verify that the installer starts before the current application is closed.
$deadline=[Diagnostics.Stopwatch]::StartNew();$captured=$false;$reported=-1
while(-not $test.process.HasExited -and $deadline.Elapsed.TotalSeconds -lt 110){
 $test.process.Refresh()
 $second=[int]$deadline.Elapsed.TotalSeconds;if($second -ne $reported){Write-Output ("Installer pid="+$test.process.Id+" windows:"+[InstallerWindows]::Describe($test.childPID));$reported=$second}
 if(-not $captured -and [InstallerWindows]::Find($test.childPID) -ne [IntPtr]::Zero){
  $bounds=[Windows.Forms.Screen]::PrimaryScreen.Bounds
  $bitmap=New-Object Drawing.Bitmap($bounds.Width,$bounds.Height);$graphics=[Drawing.Graphics]::FromImage($bitmap)
  $graphics.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size);$bitmap.Save((Join-Path $PWD 'installation-animation.png'));$graphics.Dispose();$bitmap.Dispose();$captured=$true
 }
 Start-Sleep -Milliseconds 100
}
Get-Content 'job-success-out.txt','job-success-err.txt'
if(-not $captured){throw 'The installation progress window was not visible'}
if(-not $test.process.WaitForExit(1000)){Stop-Process -Id $test.process.Id -Force;throw 'Installation did not complete'}
Get-Content 'job-success-out.txt','job-success-err.txt'
if($test.process.ExitCode -ne 0){throw 'Installation process failed'}
if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $test.hash){throw 'Wrong installed executable'}
if(Test-Path -LiteralPath $test.job){throw 'Temporary job or backup retained after healthy UI acknowledgement'}
if(Test-Path -LiteralPath ($target+'.previous')){throw 'Visible backup retained'}
if([IO.File]::ReadAllText($sentinel) -ne 'existing user data fixture'){throw 'User data changed'}
$running=Get-Process Ludemis -ErrorAction SilentlyContinue | Where-Object {$_.Path -eq $target}
if(-not $running){throw 'Updated Ludemis is not running'}
# Simulate a reserved sibling backup from the 1.12 updater. A fresh normal start must clean it.
$running | Stop-Process -Force
Copy-Item '..\Ludemis.exe' ($target+'.previous')
$relaunched=Start-Process -FilePath $target -PassThru
Start-Sleep -Seconds 18
if(Test-Path -LiteralPath ($target+'.previous')){throw 'Legacy visible backup was not removed after successful UI startup'}
$running=Get-Process Ludemis -ErrorAction SilentlyContinue | Where-Object {$_.Path -eq $target}
if(-not $running){throw 'Legacy-transition application exited'}
$bounds=[Windows.Forms.Screen]::PrimaryScreen.Bounds;$bitmap=New-Object Drawing.Bitmap($bounds.Width,$bounds.Height);$graphics=[Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($bounds.Location,[Drawing.Point]::Empty,$bounds.Size);$bitmap.Save((Join-Path $PWD 'windows-launch.png'));$graphics.Dispose();$bitmap.Dispose()
Write-Output 'Healthy UI acknowledgement, replacement, automatic cleanup, legacy cleanup and data preservation passed.'
# Failed launch must restore the old executable before removing its hidden temporary backup.
$rollbackTarget=Join-Path $folder 'rollback.exe'
& "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:winexe "/out:$rollbackTarget" $fixtureSource
$rollbackHash=(Get-FileHash -LiteralPath $rollbackTarget -Algorithm SHA256).Hash
$failure=Prepare-Job 'job-failure' $rollbackTarget $true
$wait=[Diagnostics.Stopwatch]::StartNew()
while(-not $failure.process.HasExited -and $wait.Elapsed.TotalSeconds -lt 35){
 $failure.process.Refresh()
 if([InstallerWindows]::Find($failure.childPID) -ne [IntPtr]::Zero -and $wait.Elapsed.TotalSeconds -gt 5){
  try{[InstallerWindows]::Close($failure.childPID)}catch{if(-not $failure.process.HasExited){throw}}
 }
 Start-Sleep -Milliseconds 200
}
if(-not $failure.process.WaitForExit(1000)){Stop-Process -Id $failure.process.Id -Force;throw 'Rollback timed out'}
Get-Content 'job-failure-out.txt','job-failure-err.txt'
if((Get-FileHash -LiteralPath $rollbackTarget -Algorithm SHA256).Hash -ne $rollbackHash){throw 'Rollback did not restore original executable'}
if(Test-Path -LiteralPath $failure.job){throw 'Recovered failed installation did not clean temporary files'}
Write-Output 'Rollback after launch failure passed.'
