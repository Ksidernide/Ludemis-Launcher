const {chromium}=require('playwright');
const fs=require('fs'),assert=require('node:assert/strict');
(async()=>{
 const real=!!process.env.LUDEMIS_CDP;
 const browser=real?await chromium.connectOverCDP('http://127.0.0.1:9222'):await chromium.launch({headless:true});
 const page=real?browser.contexts()[0].pages()[0]:await browser.newPage({viewport:{width:1200,height:800}});
 if(real){await page.waitForFunction(()=>typeof LudemisUpdates!=='undefined');await page.screenshot({path:'wails-interface.png'});await page.evaluate(()=>{const b=document.createElement('button');b.id='settings';b.textContent='Vérifier';document.querySelector('#app').appendChild(b)})}
 else await page.setContent('<style>body{margin:0}#app{height:800px}</style><main id="app"><button id="settings" data-check-update>Vérifier</button></main>');
 if(!real){await page.addStyleTag({content:fs.readFileSync('updates.css','utf8')});await page.addScriptTag({content:fs.readFileSync('updates.js','utf8')})}
 await page.evaluate(()=>{
  window.calls=[];window.failInstall=true;window.settings=document.querySelector('#settings');settings.focus();
  window.ui=LudemisUpdates.create({call:async method=>{calls.push(method);if(method==='CheckForUpdate')return {available:true,version:'1.11',notes:'<script>fail()</script>\nCorrections.'};if(method==='InstallUpdate'&&failInstall)throw Error('Ferme ton jeu avant de redémarrer Ludemis.')},notify:()=>{}});
  return ui.check(true);
 });
 const box=await page.locator('.update-screen').boundingBox();const size=await page.evaluate(()=>({width:innerWidth,height:innerHeight}));assert.equal(box.width,size.width);assert.equal(box.height,size.height);
 assert.equal(await page.locator('#app').evaluate(e=>e.inert),true);
 await page.getByRole('button',{name:'Télécharger la mise à jour'}).click();
 await page.getByRole('button',{name:'Redémarrer et installer'}).waitFor();
 await page.getByRole('button',{name:'Plus tard'}).click();
 assert.equal(await page.evaluate(()=>document.activeElement.id),'settings');
 await page.evaluate(()=>ui.check(true));
 await page.getByRole('button',{name:'Redémarrer et installer'}).click();
 await page.getByRole('status').filter({hasText:'Ferme ton jeu'}).waitFor();
 await page.keyboard.press('Tab');assert.equal(await page.evaluate(()=>document.activeElement.dataset.update),'later');
 await page.keyboard.press('Tab');assert.equal(await page.evaluate(()=>document.activeElement.dataset.update),'install');
 await page.screenshot({path:'update-screen.png'});
 await page.keyboard.press('Escape');assert.equal(await page.locator('.update-screen').count(),0);
 assert.equal(await page.locator('#app').evaluate(e=>e.inert),false);
 assert.deepEqual(await page.evaluate(()=>calls),['CheckForUpdate','DownloadUpdate','CheckForUpdate','InstallUpdate']);
 await browser.close();console.log('Update UI: layout, download, ready retention, restart error and focus passed.');
})().catch(e=>{console.error(e);process.exit(1)});
