﻿$ErrorActionPreference = 'Stop'
$target = %s
$staged = %s
$expected = %s
$backup = $target + '.previous'
$moved = $false
$workingDirectory = [System.IO.Path]::GetDirectoryName($target)
try {
  $process = Get-Process -Id %d -ErrorAction SilentlyContinue
  if ($process -and -not $process.WaitForExit(60000)) { throw 'Ludemis ne s''est pas fermé. Réessaie la mise à jour.' }
  if ((Get-FileHash -LiteralPath $staged -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected.ToLowerInvariant()) { throw 'Le fichier téléchargé est endommagé.' }
  if (Test-Path -LiteralPath $backup) { Remove-Item -LiteralPath $backup -Force }
  Move-Item -LiteralPath $target -Destination $backup
  $moved = $true
  Move-Item -LiteralPath $staged -Destination $target
  $started = Start-Process -FilePath $target -WorkingDirectory $workingDirectory -PassThru
  if ($started.WaitForExit(3000) -and $started.ExitCode -ne 0) { throw 'La nouvelle version n''a pas pu démarrer.' }
} catch {
  $message = $_.Exception.Message
  if ($moved) {
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue }
    try { Copy-Item -LiteralPath $backup -Destination $target -Force -ErrorAction Stop }
    catch { $message += [Environment]::NewLine + 'Restauration impossible. Copie de secours : ' + $backup + [Environment]::NewLine + $_.Exception.Message }
    if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target -WorkingDirectory $workingDirectory -ErrorAction SilentlyContinue }
  }
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show('Mise à jour impossible. Tes données sont conservées.' + [Environment]::NewLine + $message, 'Ludemis') | Out-Null
} finally {
  Remove-Item -LiteralPath $staged -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
}
