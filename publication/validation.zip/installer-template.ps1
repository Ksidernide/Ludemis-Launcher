﻿$ErrorActionPreference = 'Stop'
$target = %s
$staged = %s
$expected = %s
$job = %s
$token = %s
$backup = Join-Path $job 'previous.exe'
$ready = Join-Path $job 'ready'
$changed = $false
$keepBackup = $false
$parentClosed = $false
$started = $null
$form = $null
$workingDirectory = [System.IO.Path]::GetDirectoryName($target)
function Show-InstallStatus($text) {
  if (-not $script:form) {
    $script:form = New-Object System.Windows.Forms.Form
    $script:form.Text = 'Ludemis'
    $script:form.ClientSize = New-Object System.Drawing.Size(450,155)
    $script:form.StartPosition = 'CenterScreen'
    $script:form.FormBorderStyle = 'FixedDialog'
    $script:form.ControlBox = $false
    $script:form.TopMost = $true
    $script:form.BackColor = [System.Drawing.Color]::FromArgb(16,35,38)
    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'Mise à jour de Ludemis'
    $title.ForeColor = [System.Drawing.Color]::FromArgb(236,245,241)
    $title.Font = New-Object System.Drawing.Font('Segoe UI',16)
    $title.AutoSize = $true
    $title.Location = New-Object System.Drawing.Point(25,20)
    $script:statusLabel = New-Object System.Windows.Forms.Label
    $script:statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(183,205,197)
    $script:statusLabel.AutoSize = $true
    $script:statusLabel.Location = New-Object System.Drawing.Point(27,65)
    $bar = New-Object System.Windows.Forms.ProgressBar
    $bar.Style = 'Marquee'
    $bar.MarqueeAnimationSpeed = 28
    $bar.Size = New-Object System.Drawing.Size(395,8)
    $bar.Location = New-Object System.Drawing.Point(27,110)
    $script:form.Controls.AddRange(@($title,$script:statusLabel,$bar))
    $script:form.Show()
  }
  $script:statusLabel.Text = $text
  [System.Windows.Forms.Application]::DoEvents()
}
try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [System.IO.File]::WriteAllText((Join-Path $job 'installer.started'),$token)
  $process = Get-Process -Id %d -ErrorAction SilentlyContinue
  $wait = [System.Diagnostics.Stopwatch]::StartNew()
  while ($process -and -not $process.HasExited) {
    if ($wait.Elapsed.TotalSeconds -ge 60) { throw 'Ludemis ne s''est pas fermé.' }
    Start-Sleep -Milliseconds 100
    $process.Refresh()
  }
  $parentClosed = $true
  Show-InstallStatus 'Vérification de la mise à jour…'
  if ((Get-FileHash -LiteralPath $staged -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected.ToLowerInvariant()) { throw 'Le fichier téléchargé est endommagé.' }
  Copy-Item -LiteralPath $target -Destination $backup -Force
  $oldHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
  if ((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash -ne $oldHash) { throw 'La sauvegarde temporaire a échoué.' }
  Show-InstallStatus 'Installation en cours…'
  $changed = $true
  Copy-Item -LiteralPath $staged -Destination $target -Force
  if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected.ToLowerInvariant()) { throw 'La copie de la mise à jour a échoué.' }
  Show-InstallStatus 'Redémarrage de Ludemis…'
  $arguments = @('--ludemis-update-job',('"'+$job+'"'),'--ludemis-update-token',$token)
  $started = Start-Process -FilePath $target -ArgumentList $arguments -WorkingDirectory $workingDirectory -PassThru
  $startedHandle = $started.Handle
  $wait.Restart()
  while ($true) {
    if ((Test-Path -LiteralPath $ready) -and [System.IO.File]::ReadAllText($ready) -eq $token) { break }
    if ($started.HasExited) { throw 'La nouvelle version n''a pas pu démarrer.' }
    if ($wait.Elapsed.TotalSeconds -ge 90) { throw 'La nouvelle version ne répond pas.' }
    Show-InstallStatus 'Ouverture de ta collection…'
    Start-Sleep -Milliseconds 100
    $started.Refresh()
  }
  Show-InstallStatus 'Finalisation…'
  Remove-Item -LiteralPath $backup -Force
} catch {
  $message = $_.Exception.Message
  if ($changed) {
    if ($started -and -not $started.HasExited) { Stop-Process -Id $started.Id -Force -ErrorAction SilentlyContinue; $started.WaitForExit(10000) | Out-Null }
    try {
      $alreadyRestored = (Test-Path -LiteralPath $target) -and ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $oldHash)
      if (-not $alreadyRestored) { Copy-Item -LiteralPath $backup -Destination $target -Force -ErrorAction Stop }
      if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $oldHash) { throw 'La restauration a échoué.' }
    } catch {
      $keepBackup = $true
      $message += [Environment]::NewLine + 'Copie de secours conservée : ' + $backup
    }
  }
  if ($parentClosed -and -not $keepBackup -and (Test-Path -LiteralPath $target)) {
    try { Start-Process -FilePath $target -WorkingDirectory $workingDirectory -ErrorAction Stop }
    catch { $keepBackup = $true; $message += [Environment]::NewLine + $_.Exception.Message }
  }
  if ($form) { $form.Close() }
  [System.Windows.Forms.MessageBox]::Show('Mise à jour impossible. Tes données sont conservées.' + [Environment]::NewLine + $message,'Ludemis') | Out-Null
} finally {
  if ($form) { $form.Dispose() }
  if (-not $keepBackup) { Remove-Item -LiteralPath $job -Recurse -Force -ErrorAction SilentlyContinue }
}
