(function(global){
 'use strict';
 const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function markup(release,state,message,percent){
  const ready=state==='ready',loading=state==='downloading'||state==='installing';
  return `<section class="update-content"><div class="update-emblem"><img src="/ludemis-logo.png" alt=""></div><span class="update-eyebrow">LUDEMIS · MISE À JOUR</span><h1>${ready?'Tout est prêt.':state==='installing'?'À tout de suite.':'Une nouvelle version t’attend.'}</h1><p class="update-lead">Version ${escape(release.version)} <span>·</span> Ta collection reste avec toi.</p><div class="update-notes"><h2>Les nouveautés</h2><p>${escape(release.notes||'Améliorations et corrections de Ludemis.')}</p></div>${state==='downloading'?`<div class="update-progress"><progress max="100" value="${Math.max(0,Math.min(100,percent||0))}" aria-label="Téléchargement de la mise à jour"></progress><span>${Math.round(percent||0)} %</span></div>`:''}<p class="update-message" role="status">${escape(message||'')}</p><div class="update-actions"><button type="button" data-update="${ready?'install':'download'}" class="update-primary" ${loading?'disabled':''}>${state==='installing'?'Redémarrage…':state==='downloading'?'Téléchargement…':ready?'Redémarrer et installer':'Télécharger la mise à jour'}</button><button type="button" data-update="later" ${loading?'disabled':''}>Plus tard</button></div></section>`;
 }
 function create(options){
  let release=null,state='available',message='',percent=0,root=null,checking=false,dismissed='',returnFocus=null,autoStarted=false;
  function draw(){if(root)root.innerHTML=markup(release,state,message,percent)}
  function close(){if(state==='downloading'||state==='installing')return;dismissed=release?.version||'';if(root){root.remove();root=null;const app=global.document.querySelector('#app');if(app)app.inert=false}returnFocus?.focus?.()}
  function show(r){
   const keepReady=state==='ready'&&release?.version===r.version;release=r;state=keepReady?'ready':'available';message=keepReady?'Ludemis va se fermer, installer la mise à jour et se rouvrir.':'';percent=keepReady?100:0;
   if(!root){returnFocus=global.document.activeElement;root=global.document.createElement('div');root.className='update-screen';root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-label','Mise à jour de Ludemis');global.document.body.appendChild(root);const app=global.document.querySelector('#app');if(app)app.inert=true;root.addEventListener('click',e=>{const action=e.target.closest('[data-update]')?.dataset.update;if(action==='later')close();else if(action==='download')download();else if(action==='install')install()});root.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}if(e.key==='Tab'){const buttons=[...root.querySelectorAll('button:not(:disabled)')];if(!buttons.length){e.preventDefault();return}const i=buttons.indexOf(global.document.activeElement);if(i<0||(e.shiftKey&&i===0)||(!e.shiftKey&&i===buttons.length-1)){e.preventDefault();buttons[e.shiftKey?buttons.length-1:0].focus()}}})}
   draw();root.querySelector('button')?.focus();
  }
  async function check(manual=false){
   if(checking||state==='downloading'||state==='installing')return;
   checking=true;
   try{const r=await options.call('CheckForUpdate');if(r?.available&&(manual||r.version!==dismissed)){if(!manual&&options.blocked?.()){global.setTimeout(()=>check(false),30000);return}show(r)}else if(manual)options.notify('Ludemis est à jour.')}catch(e){if(manual)options.notify(String(e?.message||e))}finally{checking=false}
  }
  async function download(){if(state==='downloading'||state==='installing')return;state='downloading';message='Téléchargement et vérification du fichier…';draw();try{await options.call('DownloadUpdate');state='ready';message='Ludemis va se fermer, installer la mise à jour et se rouvrir.'}catch(e){state='available';message=String(e?.message||e)}draw();root?.querySelector('button')?.focus()}
  async function install(){if(state!=='ready')return;state='installing';message='Fermeture de Ludemis…';draw();try{await options.call('InstallUpdate')}catch(e){state='ready';message=String(e?.message||e);draw();root?.querySelector('button')?.focus()}}
  function progress(p){if(state!=='downloading'||!root)return;percent=p?.total>0?Math.min(100,100*p.received/p.total):0;const bar=root.querySelector('progress'),label=root.querySelector('.update-progress span');if(bar)bar.value=percent;if(label)label.textContent=`${Math.round(percent)} %`}
  function start(){if(autoStarted)return;autoStarted=true;options.events?.('update:progress',progress);global.setTimeout(()=>check(false),3000);global.setInterval(()=>check(false),6*60*60*1000);global.document.addEventListener('click',e=>{if(e.target.closest('[data-check-update]'))check(true)})}
  return {start,check,progress};
 }
 const api={create,markup};if(typeof module!=='undefined'&&module.exports)module.exports=api;else global.LudemisUpdates=api;
})(globalThis);
